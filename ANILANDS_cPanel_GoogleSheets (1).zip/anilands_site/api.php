<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
session_name(SESSION_NAME);
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','httponly'=>true,'samesite'=>'Strict']);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(array $data, int $status=200): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function input(): array { $raw=file_get_contents('php://input'); $v=json_decode($raw ?: '{}', true); return is_array($v)?$v:[]; }
function requireCsrf(array $d): void { if (!isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], (string)($d['csrf']??''))) respond(['ok'=>false,'message'=>'Phiên làm việc không hợp lệ. Vui lòng tải lại trang.'],403); }
function gas(string $action, array $payload=[]): array {
    if (GAS_WEB_APP_URL === 'PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE' || GAS_SHARED_SECRET === 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_AT_LEAST_40_CHARACTERS') respond(['ok'=>false,'message'=>'Chưa cấu hình kết nối Google Sheets trong config.php.'],503);
    $body=json_encode(['secret'=>GAS_SHARED_SECRET,'action'=>$action,'payload'=>$payload], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $ch=curl_init(GAS_WEB_APP_URL);
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25]);
    $raw=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw===false || $code>=400) respond(['ok'=>false,'message'=>'Không kết nối được Google Sheets. '.($err?:'HTTP '.$code)],502);
    $result=json_decode((string)$raw,true);
    if (!is_array($result)) respond(['ok'=>false,'message'=>'Google Sheets trả về dữ liệu không hợp lệ.'],502);
    return $result;
}
function loggedIn(): bool { return !empty($_SESSION['user']); }

$method=$_SERVER['REQUEST_METHOD']??'GET';
if ($method!=='POST') respond(['ok'=>false,'message'=>'Phương thức không hợp lệ.'],405);
$d=input(); $action=(string)($d['action']??'');
if ($action==='init') { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); respond(['ok'=>true,'csrf'=>$_SESSION['csrf'],'user'=>$_SESSION['user']??null]); }
requireCsrf($d);

if ($action==='register') {
    $name=trim((string)($d['artistName']??'')); $email=strtolower(trim((string)($d['email']??''))); $facebook=trim((string)($d['facebook']??'')); $password=(string)($d['password']??'');
    if ($name==='' || mb_strlen($name)>40) respond(['ok'=>false,'message'=>'Tên Artist không hợp lệ.'],422);
    if (!filter_var($email,FILTER_VALIDATE_EMAIL)) respond(['ok'=>false,'message'=>'Gmail không hợp lệ.'],422);
    if (!preg_match('/^https?:\/\//i',$facebook) || !filter_var($facebook,FILTER_VALIDATE_URL)) respond(['ok'=>false,'message'=>'Link Facebook không hợp lệ.'],422);
    if (strlen($password)<8 || strlen($password)>200) respond(['ok'=>false,'message'=>'Mật khẩu cần có ít nhất 8 ký tự.'],422);
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $r=gas('register',['artistName'=>$name,'email'=>$email,'facebook'=>$facebook,'passwordHash'=>$hash]);
    if (empty($r['ok'])) respond(['ok'=>false,'message'=>$r['message']??'Không thể đăng ký.'],422);
    respond(['ok'=>true,'message'=>'Đăng ký thành công.']);
}

if ($action==='login') {
    $name=trim((string)($d['artistName']??'')); $password=(string)($d['password']??'');
    if (strtolower($name)===ADMIN_USERNAME && password_verify($password,ADMIN_PASSWORD_HASH)) {
        session_regenerate_id(true); $_SESSION['user']=['role'=>'admin','artistName'=>'admin','uuid'=>'ADMIN']; respond(['ok'=>true,'redirect'=>'admin.php']);
    }
    $r=gas('getUserByArtistName',['artistName'=>$name]);
    if (empty($r['ok']) || empty($r['user']) || !password_verify($password,(string)($r['user']['passwordHash']??''))) respond(['ok'=>false,'message'=>'Tên Artist hoặc mật khẩu không đúng.'],401);
    $u=$r['user'];
    if (($u['status']??'')==='BANNED') respond(['ok'=>false,'message'=>'Tài khoản đã bị cấm.'],403);
    session_regenerate_id(true); $_SESSION['user']=['role'=>'artist','artistName'=>$u['artistName'],'uuid'=>$u['uuid']];
    respond(['ok'=>true,'redirect'=>'home.php']);
}

if ($action==='logout') { $_SESSION=[]; session_regenerate_id(true); $_SESSION['csrf']=bin2hex(random_bytes(32)); respond(['ok'=>true,'redirect'=>'index.php']); }
if (!loggedIn()) respond(['ok'=>false,'message'=>'Vui lòng đăng nhập.'],401);
$user=$_SESSION['user'];
if ($action==='myHome' && ($user['role']??'')==='artist') {
    $r=gas('getUserById',['uuid'=>$user['uuid']]); if (empty($r['ok'])) respond($r,502);
    $list=gas('listApproved',[]); respond(['ok'=>true,'user'=>$r['user']??null,'approved'=>$list['users']??[]]);
}
if (($user['role']??'')!=='admin') respond(['ok'=>false,'message'=>'Bạn không có quyền thực hiện thao tác này.'],403);
if ($action==='adminList') { $r=gas('listAll',[]); respond($r); }
if ($action==='adminStatus') {
    $uuid=trim((string)($d['uuid']??'')); $status=(string)($d['status']??'');
    if (!preg_match('/^100000[1-9][0-9]*$/',$uuid) || !in_array($status,['APPROVED','PENDING','BANNED'],true)) respond(['ok'=>false,'message'=>'Dữ liệu không hợp lệ.'],422);
    respond(gas('setStatus',['uuid'=>$uuid,'status'=>$status]));
}
respond(['ok'=>false,'message'=>'Thao tác không tồn tại.'],404);
