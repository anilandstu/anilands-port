ANILANDS — cPanel + Google Sheets

1) GOOGLE SHEETS
- Spreadsheet ID đã điền sẵn trong hướng dẫn này: 15KCeZ5RJafim42c_QgTpi1AqoXAsQ-8XHAwrWcX68yw
- Mở Google Sheet > Extensions (Tiện ích mở rộng) > Apps Script.
- Dán nội dung google-apps-script/Code.gs vào Code.gs.
- Trong Apps Script > Project Settings > Script Properties, thêm:
  ANILANDS_SPREADSHEET_ID = 15KCeZ5RJafim42c_QgTpi1AqoXAsQ-8XHAwrWcX68yw
  ANILANDS_SHARED_SECRET = một chuỗi bí mật ngẫu nhiên dài ít nhất 40 ký tự
- Chạy hàm setup không cần thiết; tab Artists sẽ tự tạo ở lần gọi đầu tiên.
- Deploy > New deployment > Web app; Execute as: Me; Who has access: Anyone.
- Sao chép URL /exec.

2) CPANEL / LANIT
- Tải các file trong thư mục này lên public_html.
- Mở config.php:
  GAS_WEB_APP_URL = URL /exec vừa sao chép.
  GAS_SHARED_SECRET = đúng chuỗi đã đặt trong Script Properties.
- Đảm bảo hosting bật PHP cURL và PHP session.
- Truy cập tên miền để mở index.php.

3) TÀI KHOẢN ADMIN
- Tên: admin
- Mật khẩu ban đầu: tri12345
- Đổi mật khẩu sau khi cài đặt bằng cách tạo hash mới bằng PHP password_hash() rồi thay ADMIN_PASSWORD_HASH trong config.php.

4) DỮ LIỆU
- Dữ liệu được lưu trong tab Artists riêng, không xóa hay ghi đè các tab khác.
- UUID bắt đầu từ 1000001.
- Trạng thái ban đầu là PENDING; chỉ APPROVED mới xuất hiện trong danh sách người tham dự.
- Mật khẩu Artist được lưu dưới dạng password hash. Admin không thể xem mật khẩu gốc; đây là cách bảo vệ tài khoản.

LƯU Ý
- Dùng HTTPS cho tên miền.
- Không chia sẻ GAS_SHARED_SECRET hoặc quyền chỉnh sửa Apps Script.
- Nếu Google Apps Script đang triển khai phiên bản cũ, vào Deploy > Manage deployments > Edit > New version > Deploy sau khi sửa Code.gs.
