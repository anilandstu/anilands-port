let csrf = '';
async function api(action, data={}) {
  const response = await fetch('api.php', {method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({action,csrf,...data})});
  const result = await response.json();
  if (!response.ok && result.message) throw new Error(result.message);
  return result;
}
function showMessage(message, error=false) { const el=document.getElementById('message'); if(el){el.textContent=message;el.classList.toggle('error',error);} }
function formData(form) { return Object.fromEntries(new FormData(form).entries()); }
(async function start(){
  try { const init=await api('init'); csrf=init.csrf||''; }
  catch(e){ showMessage(e.message,true); return; }
  const tabs=document.querySelectorAll('[data-tab]');
  tabs.forEach(tab=>tab.addEventListener('click',()=>{tabs.forEach(t=>t.classList.toggle('active',t===tab));document.getElementById('loginForm').classList.toggle('hidden',tab.dataset.tab!=='login');document.getElementById('registerForm').classList.toggle('hidden',tab.dataset.tab!=='register');showMessage('');}));
  const login=document.getElementById('loginForm'); if(login) login.addEventListener('submit',async e=>{e.preventDefault();const b=login.querySelector('button[type=submit]');b.disabled=true;try{const r=await api('login',formData(login));location.href=r.redirect;}catch(err){showMessage(err.message,true);}finally{b.disabled=false;}});
  const reg=document.getElementById('registerForm'); if(reg) reg.addEventListener('submit',async e=>{e.preventDefault();const b=reg.querySelector('button[type=submit]');b.disabled=true;try{const r=await api('register',formData(reg));showMessage(r.message);reg.reset();document.querySelector('[data-tab="login"]').click();}catch(err){showMessage(err.message,true);}finally{b.disabled=false;}});
  const forgot=document.getElementById('forgotBtn'); if(forgot) forgot.addEventListener('click',()=>alert('Vui lòng liên hệ admin hoặc gửi yêu cầu thay đổi mật khẩu qua gmail: anilandstu.onl@gmail.com'));
  document.querySelectorAll('[data-logout]').forEach(b=>b.addEventListener('click',async()=>{try{const r=await api('logout');location.href=r.redirect;}catch(e){showMessage(e.message,true);}}));
  if(document.getElementById('artistCard')) loadHome();
  if(document.getElementById('adminRows')) loadAdmin();
})();
async function loadHome(){try{const r=await api('myHome');const u=r.user;if(!u)throw new Error('Không tìm thấy tài khoản.');document.getElementById('artistName').textContent=u.artistName;document.getElementById('artistUuid').textContent=u.uuid;const approved=u.status==='APPROVED';document.getElementById('artistCard').classList.toggle('gold',approved);document.getElementById('artistCard').classList.toggle('silver',!approved);document.getElementById('artistStatus').textContent=approved?'Đã duyệt':(u.status==='BANNED'?'Đã bị cấm':'Chưa phê duyệt');const list=document.getElementById('attendeeList');list.replaceChildren();(r.approved||[]).forEach(x=>{const li=document.createElement('li');li.textContent=x.artistName;list.appendChild(li);});}catch(e){showMessage(e.message,true);}}
async function loadAdmin(){try{const r=await api('adminList');const body=document.getElementById('adminRows');body.replaceChildren();(r.users||[]).forEach(u=>{const tr=document.createElement('tr');const values=[u.uuid,u.artistName,u.email,u.facebook,u.status];values.forEach((v,i)=>{const td=document.createElement('td');if(i===3&&v){const a=document.createElement('a');a.href=v;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Facebook';td.appendChild(a);}else td.textContent=v||'—';tr.appendChild(td);});const td=document.createElement('td');const approve=document.createElement('button');approve.className='mini-button';approve.textContent='Duyệt';approve.disabled=u.status==='APPROVED';approve.onclick=()=>setArtistStatus(u.uuid,'APPROVED');const ban=document.createElement('button');ban.className='mini-button danger';ban.textContent='Cấm';ban.disabled=u.status==='BANNED';ban.onclick=()=>setArtistStatus(u.uuid,'BANNED');const undo=document.createElement('button');undo.className='mini-button';undo.textContent='Bỏ cấm';undo.disabled=u.status!=='BANNED';undo.onclick=()=>setArtistStatus(u.uuid,'PENDING');td.append(approve,ban,undo);tr.appendChild(td);body.appendChild(tr);});if(!body.children.length)body.innerHTML='<tr><td colspan="6">Chưa có Artist.</td></tr>';}catch(e){showMessage(e.message,true);}}
async function setArtistStatus(uuid,status){try{const r=await api('adminStatus',{uuid,status});showMessage(r.message||'Đã cập nhật.');await loadAdmin();}catch(e){showMessage(e.message,true);}}
