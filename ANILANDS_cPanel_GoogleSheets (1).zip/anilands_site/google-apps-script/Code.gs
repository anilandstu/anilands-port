/** ANILANDS Google Sheets bridge. Deploy as Web App: Execute as Me, access Anyone. */
const TAB_NAME = 'Artists';
const HEADERS = ['UUID','ArtistName','Email','Facebook','PasswordHash','Status','CreatedAt'];
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const props = PropertiesService.getScriptProperties();
    const secret = props.getProperty('ANILANDS_SHARED_SECRET');
    const spreadsheetId = props.getProperty('ANILANDS_SPREADSHEET_ID');
    if (!secret || !spreadsheetId || body.secret !== secret) return output({ok:false,message:'Unauthorized'});
    const sheet = getSheet_(spreadsheetId);
    const p = body.payload || {};
    let result;
    switch (body.action) {
      case 'register': result = register_(sheet,p); break;
      case 'getUserByArtistName': result = findBy_(sheet,2,String(p.artistName||'')); break;
      case 'getUserById': result = findBy_(sheet,1,String(p.uuid||'')); break;
      case 'listAll': result = {ok:true,users:readUsers_(sheet)}; break;
      case 'listApproved': result = {ok:true,users:readUsers_(sheet).filter(u=>u.status==='APPROVED')}; break;
      case 'setStatus': result = setStatus_(sheet,p); break;
      default: result = {ok:false,message:'Unknown action'};
    }
    return output(result);
  } catch (err) { return output({ok:false,message:String(err && err.message || err)}); }
}
function output(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function getSheet_(id) {
  const ss=SpreadsheetApp.openById(id); let sh=ss.getSheetByName(TAB_NAME);
  if (!sh) { sh=ss.insertSheet(TAB_NAME); sh.appendRow(HEADERS); sh.setFrozenRows(1); }
  if (sh.getLastRow()===0) sh.appendRow(HEADERS);
  return sh;
}
function readUsers_(sh) {
  if (sh.getLastRow()<2) return [];
  const rows=sh.getRange(2,1,sh.getLastRow()-1,HEADERS.length).getValues();
  return rows.filter(r=>r[0]!=='' && r[0]!==null).map(r=>({uuid:String(r[0]),artistName:String(r[1]),email:String(r[2]),facebook:String(r[3]),passwordHash:String(r[4]),status:String(r[5]),createdAt:String(r[6])}));
}
function register_(sh,p) {
  const users=readUsers_(sh); const name=String(p.artistName||'').trim(); const email=String(p.email||'').trim().toLowerCase();
  if (users.some(u=>u.artistName.toLowerCase()===name.toLowerCase())) return {ok:false,message:'Tên Artist đã được sử dụng.'};
  if (users.some(u=>u.email.toLowerCase()===email)) return {ok:false,message:'Gmail đã được sử dụng.'};
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try {
    const fresh=readUsers_(sh); let max=1000000;
    fresh.forEach(u=>{const n=Number(u.uuid);if(Number.isFinite(n)&&n>max)max=n;});
    const uuid=String(max+1);
    sh.appendRow([uuid,name,email,String(p.facebook||''),String(p.passwordHash||''),'PENDING',new Date()]);
    return {ok:true,uuid};
  } finally { lock.releaseLock(); }
}
function findBy_(sh,col,value) {
  const users=readUsers_(sh); const key=value.toLowerCase();
  const u=users.find(x=>String(col===1?x.uuid:x.artistName).toLowerCase()===key);
  return {ok:true,user:u||null};
}
function setStatus_(sh,p) {
  const uuid=String(p.uuid||''); const status=String(p.status||'');
  const values=sh.getRange(2,1,Math.max(sh.getLastRow()-1,0),1).getValues();
  for(let i=0;i<values.length;i++) if(String(values[i][0])===uuid) { sh.getRange(i+2,6).setValue(status); return {ok:true,message:'Đã cập nhật trạng thái.'}; }
  return {ok:false,message:'Không tìm thấy Artist.'};
}
