<?php
// ANILANDS configuration. Keep this file on the server; never place secrets in HTML/JS.
const GAS_WEB_APP_URL = 'PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE';
const GAS_SHARED_SECRET = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_AT_LEAST_40_CHARACTERS';
const ADMIN_USERNAME = 'admin';
// Initial Admin password: tri12345. Change it after first deployment.
const ADMIN_PASSWORD_HASH = '$2y$12$9VPN67qx2EotHWhIt2RRMufEdQQTdF/sajjccHQodHKukAUiPDspG';
const SESSION_NAME = 'ANILANDS_SESSION';
